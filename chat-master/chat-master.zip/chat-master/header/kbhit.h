/*
	Universidade Federal de Alagoas - Campus A.C Simões
	Desenvolvedor: João Correia
	Data: 25/09/2015
	GitHub: www.github.com/correiajoao/chat 
*/

#ifndef KBHIT_H
#define KBHIT_H

//Essa função verifica se o usuário apertou alguma tecla
int kbhit();

//Essa função aguarda uma tecla ser apertada
void waitKey();
#endif

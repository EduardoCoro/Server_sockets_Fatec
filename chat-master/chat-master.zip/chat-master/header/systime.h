/*
	Universidade Federal de Alagoas - Campus A.C Simões
	Desenvolvedor: João Correia
	Data: 25/09/2015
	GitHub: www.github.com/correiajoao/chat 
*/

#ifndef SYSTIME_H
#define SYSTIME_H

//Essa funão retorna uma string com a hora e minutos do sistema
char* getHourMinutes();

//Essa funão retorna uma string com a hora, minutos e segundos do sistema
char* getHourMinutesSeconds();


#endif
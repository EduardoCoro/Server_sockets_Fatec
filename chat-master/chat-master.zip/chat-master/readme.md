To build the project: 
```
	bash make.sh
```
To start the server:
```
	./server
```
To start the client:
```
	./client
``` 

YouTube link

[![Bate-papo](https://i.ytimg.com/vi_webp/oExb4u2m9mg/mqdefault.webp)](https://www.youtube.com/watch?v=oExb4u2m9mg&feature=youtu.be "Bate-papo")
